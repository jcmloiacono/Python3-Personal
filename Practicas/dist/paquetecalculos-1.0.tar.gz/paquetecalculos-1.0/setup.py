from setuptools import setup

setup(
    
    name="paquetecalculos",
    version="1.0",
    description="Paquete de Redondeo y Calculos Matematicos",
    author="Jean Carlo Lo Iacono",
    author_email="Jcmartinez1702@gmail.com",
    url="www.wits.cl",
    packages=["Calculos", "Calculos.Basicos"]
    
    )
